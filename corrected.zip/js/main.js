$('.menuToggler').click(function () {
    $('.menu.d-flex.end.center').toggleClass('active')
})